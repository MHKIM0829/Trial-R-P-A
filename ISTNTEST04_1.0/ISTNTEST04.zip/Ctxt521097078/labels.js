﻿
/** String table (English/French/German) */
GLOBAL.labels.set({
	menu: {
    about: { _comment:"About menu item", _type:"XMIT", en:"About...", fr:"A propos..." },
    restart: { _comment:"Restart menu item", _type:"XMIT", en:"Restart", fr:"Redémarrer" },
		stop: { _comment:"Stop menu item", _type:"XMIT", en:"Shutdown", fr:"Arrêt", de:"Schließen" },
    main: { _comment:"Main menu menu item", _type:"XMIT", en:"Main Menu", fr:"Menu principal" },
		menu1: { _comment:"Submenu example label", _type:"XMIT", en:"Menu 1"},
		menu2: { _comment:"Submenu example label", _type:"XMIT", en:"Menu 2"},
    test: { _comment:"Test menu item", _type:"XMIT", en:"Test Menu", fr:"Menu test" },
		test1: { _comment:"Submenu test example label", _type:"XMIT", en:"Test 1"},
		test2: { _comment:"Submenu tes example label", _type:"XMIT", en:"Test 2"},
    reportIncident: { _comment:"Incident report menu item", _type:"XMIT", en:"Report an incident", fr:"Soumettre un incident", de:"Report an incident" },
    recordTraces: { _comment:"Report traces menu item", _type:"XMIT", en:"Record traces", fr:"Enregistrer des traces", de:"Record traces" },
		languages: { _comment:"Language list menu item", _type:"XMIT", en:"Languages" },
		popupTests: { _comment:"Menu for testing popups (only displayed in debug mode)", _type:"XMIT", en:"Popup tests" },
		galaxyAPI: { _comment:"Menu for Galaxy interactions", _type:"XMIT", en:"Galaxy API" }
	},
	changeLanguagePopup: {
		title: { _comment: "Title of the popup displayed when the user changes the language", _type: "XTIT", en:"Language change"},
		changeInfo: { _comment: "Indication of the selected language", _type: "XMSG", en:"You changed language to "},
		requestRestart: { _comment: "The user must restart the agent to see changes", _type: "XMSG", en:"Changes will be taken in account after a restart of the agent"}
	},
	aboutPopup: {
		title: { _comment: "Title of the about popup", _type: "XTIT", en:"About...", fr:"A propos...", de:"Uber..." },
		projectLabel: { _comment: "Project", _type: "XFLD", en:"Project", fr:"Projet", de:"Projekt" },
		projectVersion: { _comment: "Project version", _type: "XFLD", en:"Project version", fr:"Version projet", de:"Projektversion" },
		productVersion: { _comment: "Product version", _type: "XFLD", en:"Product version", fr:"Version produit", de:"Produktversion" },
		studioVersion: { _comment: "Studio version", _type: "XFLD", en:"Studio version", fr:"Version Studio", de:"Studio version" },
		environment: { _comment: "Environment", _type: "XFLD", en:"Environment", fr:"Environnement", de:"Environment" },
		frameworkVersion: { _comment: "Framework version", _type: "XFLD", en:"Framework version", fr:"Version langage", de:"Framework-Version" }
	},
	restartPopup: {
		title: { _type:"XTIT", en:"Agent restart", fr:"Redémarrage Agent", de:"Wieder starten" },
		label: {  _type:"XFLD",
			en:"Are you sure you want to restart Agent ?", 
			fr:"Etes-vous certain de redémarrer Agent ?",
			de:"Are you sure you want to restart Agent ?"}
	},
	stopPopup: {
		title: { _type:"XTIT", en:"Agent shutdown", fr:"Arrêt Agent", de:"Schließen" },
		label: { _type:"XFLD", 
			en:"Are you sure you want to stop Agent ?", 
			fr:"Etes-vous certain de quitter Agent ?",
			de:"Are you sure you want to stop Agent ?"}
	},
	updatePopup: {
		title: { _type:"XTIT", en:"Agent update", fr:"Mise à jour Agent", de:"Agent update" },
		label: { _type:"XFLD", 
			en:"A new version is available, do you want to restart now ?", 
			fr:"Une nouvelle version est disponible, voulez-vous redémarrer maintenant ?",
			de:"A new version is available, do you want to restart now ?"}
	},
	env: {
		none: { _comment: "Environnement courant (probably obsolete, naming problem between none and all)", _type: "XFLD", en:"All", fr:"Tous", de:"All" },
		prod: { _comment: "Environnement courant (probably obsolete)", _type: "XFLD", en:"Production", fr:"Production", de:"Production" },
		qual: { _comment: "Environnement courant (probably obsolete)", _type: "XFLD", en:"Qualification", fr:"Qualification", de:"Qualification" },
		test: { _comment: "Environnement courant (probably obsolete)", _type: "XFLD", en:"Test", fr:"Test", de:"Test" },
		dev: { _comment: "Environnement courant (probably obsolete)", _type: "XFLD", en:"Development", fr:"Développement", de:"Development"},
		envList: { _comment: "Environment list", _type: "XMIT", en: "Environments"}
	}
});

