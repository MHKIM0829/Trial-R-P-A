﻿
//---------------------------------------------------
// Data Structures
//---------------------------------------------------
// ----------- rootData -------------------
ctx.dataManager({
	rootData :
	{
		MyDatabase : 
		{
			PKGDetail : []
		}
	}
});
var rootData = ctx.dataManagers.rootData.create() ;

// ----------- rootData_MyDatabase -------------------
ctx.dataManager({
	rootData_MyDatabase :
	{
		PKGDetail : []
	}
});
var rootData_MyDatabase = ctx.dataManagers.rootData_MyDatabase.create() ;

// ----------- rootData_MyDatabase_PKGDetail -------------------
ctx.dataManager({
	rootData_MyDatabase_PKGDetail :
	{
		oClientID : ''
		, oSerial_number : ''
		, oEquipment_type : ''
		, oOffer_type : ''
		, oEligibility : ''
		, oDescription : ''
		, oTms : ''
		, oTban : ''
		, oChargedate : ''
		, oContractname : ''
		, oSoft : ''
		, oTeleload : ''
		, oStatus : ''
		, oRequest : ''
	}
});
var rootData_MyDatabase_PKGDetail = ctx.dataManagers.rootData_MyDatabase_PKGDetail.create() ;


//---------------------------------------------------
// Settings Structure
//---------------------------------------------------

//---------------------------------------------------
// Functional Events Declaration
//---------------------------------------------------

//---------------------------------------------------
// 
//---------------------------------------------------
