﻿
// ----------------------------------------------------------------
//   Test menu for scenario newWorkflow 
// ----------------------------------------------------------------
GLOBAL.events.START.on(function (ev) {
	if (ctx.options.isDebug) {
		// Add item in systray menu.
		systray.addMenu('', 'newWorkflow', 'Test newWorkflow', '', function (ev) {
			var rootData = ctx.dataManagers.rootData.create();
			
			// Initialize your data here.
			GLOBAL.scenarios.newWorkflow.start(rootData);
		});
	}
});

//---------------------------------------------------
// Scenario newWorkflow Starter ()
//---------------------------------------------------

// ----------------------------------------------------------------
//   Scenario: newWorkflow
// ----------------------------------------------------------------
GLOBAL.scenario({ newWorkflow: function(ev, sc) {
	var rootData = sc.data;

	sc.setMode(e.scenario.mode.clearIfRunning);
	sc.setScenarioTimeout(600000); // Default timeout for global scenario.
	sc.onError(function(sc, st, ex) { sc.endScenario(); }); // Default error handler.
	sc.onTimeout(30000, function(sc, st) { sc.endScenario(); }); // Default timeout handler for each step.
	// Initialize Loop counters
	sc.localData.Startloop = 0;
	
	sc.step(GLOBAL.steps.Start_CustomerPackag, GLOBAL.steps.Start_loop);
	sc.step(GLOBAL.steps.Start_loop, GLOBAL.steps.pCustomerPackage_mana);
	sc.step(GLOBAL.steps.pCustomerPackage_mana, GLOBAL.steps.Loops_to_the_Start_bl, 'NEXT_LOOP');
	sc.step(GLOBAL.steps.pCustomerPackage_mana, GLOBAL.steps.Start_TerminalInfos);
	sc.step(GLOBAL.steps.Start_TerminalInfos, GLOBAL.steps.Loops_to_the_Start_bl, 'NEXT_LOOP');
	sc.step(GLOBAL.steps.Start_TerminalInfos, GLOBAL.steps.pTerminalInfos_manage);
	sc.step(GLOBAL.steps.pTerminalInfos_manage, GLOBAL.steps.Loops_to_the_Start_bl, 'NEXT_LOOP');
	sc.step(GLOBAL.steps.pTerminalInfos_manage, GLOBAL.steps.pTerminalDetails_mana, 'Default');
	sc.step(GLOBAL.steps.pTerminalInfos_manage, GLOBAL.steps.pPartner_management, 'partenr');
	sc.step(GLOBAL.steps.pTerminalDetails_mana, GLOBAL.steps.Loops_to_the_Start_bl, 'NEXT_LOOP');
	sc.step(GLOBAL.steps.pTerminalDetails_mana, GLOBAL.steps.Loops_to_the_Start_bl);
	sc.step(GLOBAL.steps.Loops_to_the_Start_bl, GLOBAL.steps.Start_loop, 'NEXT_LOOP');
	sc.step(GLOBAL.steps.Loops_to_the_Start_bl, GLOBAL.steps.Close_TerminalInfos);
	sc.step(GLOBAL.steps.Close_TerminalInfos, GLOBAL.steps.Close_CustomerPackag);
	sc.step(GLOBAL.steps.Close_CustomerPackag, GLOBAL.steps.Initialize_Excel);
	sc.step(GLOBAL.steps.Initialize_Excel, GLOBAL.steps.Open_Excel);
	sc.step(GLOBAL.steps.Open_Excel, GLOBAL.steps.Set_range_table);
	sc.step(GLOBAL.steps.Set_range_table, GLOBAL.steps.Save_as_Excel);
	sc.step(GLOBAL.steps.Save_as_Excel, GLOBAL.steps.End_Excel);
	sc.step(GLOBAL.steps.End_Excel, null);
	sc.step(GLOBAL.steps.pPartner_management, GLOBAL.steps.Loops_to_the_Start_bl, 'NEXT_LOOP');
	sc.step(GLOBAL.steps.pPartner_management, GLOBAL.steps.Loops_to_the_Start_bl);
}}, ctx.dataManagers.rootData).setId('b88eed4c-77df-4d95-9a82-8877c64d8b5c') ;

// ----------------------------------------------------------------
//   Step: Start_CustomerPackag
// ----------------------------------------------------------------
GLOBAL.step({ Start_CustomerPackag: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', 'bfba0e5a-a54a-4bcd-a720-4fa590f6b447') ;
	ctx.log("Start 'CustomerPackage'");
	// Start 'CustomerPackage'
	CustomerPackage.start();
	sc.endStep(); // Start_loop
	return;
}});

// ----------------------------------------------------------------
//   Step: Start_loop
// ----------------------------------------------------------------
GLOBAL.step({ Start_loop: function(ev, sc, st) {
	var rootData = sc.data;
	
	ctx.workflow('newWorkflow', 'cc0b050d-cf0a-4d3c-b053-202879ee2032') ;
	ctx.log("Start loop");
	// Start loop
	if (sc.localData.Startloop < 0) sc.localData.Startloop = 0;
	sc.endStep(); // pCustomerPackage_mana
	return;
}});

// ----------------------------------------------------------------
//   Step: pCustomerPackage_mana
// ----------------------------------------------------------------
GLOBAL.step({ pCustomerPackage_mana: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', '30d7da26-cc45-4d94-ab29-8ae0dbd0fb27') ;
	ctx.log("pCustomerPackage management");
	// Wait until the Page loads
	CustomerPackage.pCustomerPackage.wait(function(ev) {
		ctx.log("Delay (200 ms)");
		// Delay (200 ms)
		ctx.wait(function(ev) {
			
			ctx.log("Exit loop");
			// Exit loop
			if (!CustomerPackage.pCustomerPackage.oClientID.i(sc.localData.Startloop).exist())
			{
				sc.localData.Startloop = -1 ;
				sc.endStep('NEXT_LOOP');
				return ;
			}
			else
			{
				if (rootData.MyDatabase.PKGDetail.length <= sc.localData.Startloop)
					rootData.MyDatabase.PKGDetail[sc.localData.Startloop] = ctx.dataManagers.rootData_MyDatabase_PKGDetail.create() ;
			}
			ctx.log("Get 'oClientID (1)' in 'MyDatabase.PKGDetail.oClientID'");
			rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oClientID = CustomerPackage.pCustomerPackage.oClientID.i(sc.localData.Startloop).get();
			sc.endStep(); // Start_TerminalInfos
			return;
		}, 200);
	});
}});

// ----------------------------------------------------------------
//   Step: Start_TerminalInfos
// ----------------------------------------------------------------
GLOBAL.step({ Start_TerminalInfos: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', '46a69c7d-35cc-477f-8d53-d061a7706678') ;
	ctx.log("Start 'TerminalInfos'");
	// Start 'TerminalInfos'
	TerminalInfos.start();
	sc.endStep(); // pTerminalInfos_manage
	return;
}});

// ----------------------------------------------------------------
//   Step: pTerminalInfos_manage
// ----------------------------------------------------------------
GLOBAL.step({ pTerminalInfos_manage: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', '1679d76c-bfc8-4f6d-a4f1-1cec6d0286b3') ;
	ctx.log("pTerminalInfos management");
	// Wait until the Page loads
	TerminalInfos.pTerminalInfos.wait(function(ev) {
		ctx.log("Set MyDatabase.PKGDetail.oClientID in 'oContract_id (1)'");
		TerminalInfos.pTerminalInfos.oContract_id.set(rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oClientID);
		ctx.log("Click on 'btSearch (2)'");
		TerminalInfos.pTerminalInfos.btSearch.click();
		ctx.log("Wait until 'btDetails (7)' exists");
		TerminalInfos.pTerminalInfos.btDetails.wait(function(ev) {
			ctx.log("Get 'oSerial_number (3)' in 'MyDatabase.PKGDetail.oSerial_number'");
			rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oSerial_number = TerminalInfos.pTerminalInfos.oSerial_number.get();
			ctx.log("Get 'oEquipment_type (4)' in 'MyDatabase.PKGDetail.oEquipment_type'");
			rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oEquipment_type = TerminalInfos.pTerminalInfos.oEquipment_type.get();
			ctx.log("Get 'oOffer_type (5)' in 'MyDatabase.PKGDetail.oOffer_type'");
			rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oOffer_type = TerminalInfos.pTerminalInfos.oOffer_type.get();
			ctx.log("Get 'oEligibility (6)' in 'MyDatabase.PKGDetail.oEligibility'");
			rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oEligibility = TerminalInfos.pTerminalInfos.oEligibility.get();
			ctx.log("Click on 'btDetails (7)'");
			TerminalInfos.pTerminalInfos.btDetails.click();
			// Wait until the Page loads
			TerminalInfos.pTerminalDetails.wait(function(ev) {
				sc.endStep('Default'); // pTerminalDetails management
				return;
			});
			// Wait until the Page loads
			Partner.pPartner.wait(function(ev) {
				sc.endStep('partenr'); // pPartner management
				return;
			});
		}, 0, 10000);
	});
}});

// ----------------------------------------------------------------
//   Step: pTerminalDetails_mana
// ----------------------------------------------------------------
GLOBAL.step({ pTerminalDetails_mana: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', 'aff837ad-591e-4a20-b067-03e58c2eb85a') ;
	ctx.log("pTerminalDetails management");
	// Wait until the Page loads
	TerminalInfos.pTerminalDetails.wait(function(ev) {
		ctx.log("Get 'oDescription (1)' in 'MyDatabase.PKGDetail.oDescription'");
		rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oDescription = TerminalInfos.pTerminalDetails.oDescription.get();
		ctx.log("Get 'oTms (2)' in 'MyDatabase.PKGDetail.oTms'");
		rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oTms = TerminalInfos.pTerminalDetails.oTms.get();
		ctx.log("Get 'oTban (3)' in 'MyDatabase.PKGDetail.oTban'");
		rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oTban = TerminalInfos.pTerminalDetails.oTban.get();
		ctx.log("Get 'oChargedate (4)' in 'MyDatabase.PKGDetail.oChargedate'");
		rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oChargedate = TerminalInfos.pTerminalDetails.oChargedate.get();
		ctx.log("Get 'oContractname (5)' in 'MyDatabase.PKGDetail.oContractname'");
		rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oContractname = TerminalInfos.pTerminalDetails.oContractname.get();
		ctx.log("Get 'oSoft (6)' in 'MyDatabase.PKGDetail.oSoft'");
		rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oSoft = TerminalInfos.pTerminalDetails.oSoft.get();
		ctx.log("Get 'oTeleload (7)' in 'MyDatabase.PKGDetail.oTeleload'");
		rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oTeleload = TerminalInfos.pTerminalDetails.oTeleload.get();
		ctx.log("Get 'oStatus (8)' in 'MyDatabase.PKGDetail.oStatus'");
		rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oStatus = TerminalInfos.pTerminalDetails.oStatus.get();
		ctx.log("Close 'pTerminalDetails'");
		TerminalInfos.pTerminalDetails.close();
		TerminalInfos.pTerminalDetails.waitClose(function(ev) {
			sc.endStep(); // Loops_to_the_Start_bl
			return;
		});
	});
}});

// ----------------------------------------------------------------
//   Step: Loops_to_the_Start_bl
// ----------------------------------------------------------------
GLOBAL.step({ Loops_to_the_Start_bl: function(ev, sc, st) {
	var rootData = sc.data;
	
	ctx.workflow('newWorkflow', 'b16bacb1-aace-410b-a321-9f308eab96e4') ;
	ctx.log("Loops to the Start block");
	// Loops to the Start block
	if (sc.localData.Startloop != -1)
	{
		sc.localData.Startloop++ ;
		sc.endStep('NEXT_LOOP');
		return ;
	}
	sc.endStep(); // Close_TerminalInfos
	return;
}});

// ----------------------------------------------------------------
//   Step: Close_TerminalInfos
// ----------------------------------------------------------------
GLOBAL.step({ Close_TerminalInfos: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', '2ed4b236-e298-455e-8fe4-2315e6592fd3') ;
	ctx.log("Close 'TerminalInfos'");
	// Close 'TerminalInfos'
	TerminalInfos.close();
	sc.endStep(); // Close_CustomerPackag
	return;
}});

// ----------------------------------------------------------------
//   Step: Close_CustomerPackag
// ----------------------------------------------------------------
GLOBAL.step({ Close_CustomerPackag: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', '8d0d75b1-d678-4aec-aa3e-954bb702c800') ;
	ctx.log("Close 'CustomerPackage'");
	// Close 'CustomerPackage'
	CustomerPackage.close();
	sc.endStep(); // Initialize_Excel
	return;
}});

// ----------------------------------------------------------------
//   Step: Initialize_Excel
// ----------------------------------------------------------------
GLOBAL.step({ Initialize_Excel: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', 'db3386b1-ed82-479b-bb87-5f7c48d15ad6') ;
	ctx.log("Initialize Excel");
	// Initialize Excel
	ctx.options.excel.newXlsInstance = false;
	ctx.options.excel.visible = true;
	ctx.options.excel.displayAlerts = false;
	ctx.excel.initialize();
	sc.endStep(); // Open_Excel
	return;
}});

// ----------------------------------------------------------------
//   Step: Open_Excel
// ----------------------------------------------------------------
GLOBAL.step({ Open_Excel: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', '307877e4-c9f8-4e6f-9424-a97cdc385073') ;
	ctx.log("Open Excel");
	// Open Excel
	ctx.excel.file.open("C:\\Users\\weaver7\\Documents\\Template.xlsx");
	sc.endStep(); // Set_range_table
	return;
}});

// ----------------------------------------------------------------
//   Step: Set_range_table
// ----------------------------------------------------------------
GLOBAL.step({ Set_range_table: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', 'd3c3c30b-d7ab-458c-833a-8462b2cbb03f') ;
	ctx.log("Set range table");
	// Set range table
	ctx.excel.sheet.setFullRangeValues('A',2,rootData.MyDatabase.PKGDetail,true);
	sc.endStep(); // Save_as_Excel
	return;
}});

// ----------------------------------------------------------------
//   Step: Save_as_Excel
// ----------------------------------------------------------------
GLOBAL.step({ Save_as_Excel: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', '8857f3dd-fce9-44ce-b15c-7364195600c6') ;
	ctx.log("Save as Excel");
	// Save as Excel
	
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1;
	var yyyy = today.getFullYear();
	
	var oExcelFilePath = "C:\\Users\\weaver7\\Documents\\";
	var oExcelFileName = "테스트_"+yyyy + mm + dd;
	var oExcelExtension = ".xlsx";
	
	var oExcelFilePath = oExcelFilePath + oExcelFileName + oExcelExtension;
	
	ctx.log("@@@@@oExcelFilePath@@@ :" + oExcelFilePath);
	
	ctx.excel.file.saveAs(oExcelFilePath);
	
	sc.endStep(); // End_Excel
	return;
}});

// ----------------------------------------------------------------
//   Step: End_Excel
// ----------------------------------------------------------------
GLOBAL.step({ End_Excel: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', '65ccb7c6-f2da-44ac-ae24-68fc1049b22d') ;
	ctx.log("End Excel");
	// End Excel
	ctx.excel.end();
	sc.endStep(); // end Scenario
	return;
}});

// ----------------------------------------------------------------
//   Step: pPartner_management
// ----------------------------------------------------------------
GLOBAL.step({ pPartner_management: function(ev, sc, st) {
	var rootData = sc.data;
	ctx.workflow('newWorkflow', '7c169455-3737-4698-8855-d032c5e450b8') ;
	ctx.log("pPartner management");
	// Wait until the Page loads
	Partner.pPartner.wait(function(ev) {
		ctx.log("Set MyDatabase.PKGDetail.oClientID in 'oContract_id (1)'");
		Partner.pPartner.oContract_id.set(rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oClientID);
		ctx.log("Set MyDatabase.PKGDetail.oSerial_number in 'oSerial_number (2)'");
		Partner.pPartner.oSerial_number.set(rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oSerial_number);
		ctx.log("Click on 'btSend (3)'");
		Partner.pPartner.btSend.click();
		ctx.log("Get '...' in '...'");
		// Get '...' in '...'
		rootData.MyDatabase.PKGDetail[sc.localData.Startloop].oRequest = Partner.pPartner.oRequest.get();
		ctx.log("Close 'pPartner'");
		Partner.pPartner.close();
		Partner.pPartner.waitClose(function(ev) {
			sc.endStep(); // Loops_to_the_Start_bl
			return;
		});
	});
}});
