﻿// Desktop Studio
// Auto-generated declaration file : do not modify !



var POPUPS = POPUPS || ctx.addApplication('POPUPS');



var CustomerPackage = ctx.addApplication('CustomerPackage', {"nature":"WEB3","path":"file://C:\\Users\\weaver7\\Desktop\\20190904_06 Hands-on Application\\Packages\\Packages.htm"});

CustomerPackage.pCustomerPackage = CustomerPackage.addPage('pCustomerPackage', {"comment":"file://C:\\Users\\weaver7\\Desktop\\20190904_06 Hands-on Application\\Packages\\Packages.htm","path":"file://C:\\Users\\weaver7\\Desktop\\20190904_06 Hands-on Application\\Packages\\Packages.htm"});
CustomerPackage.pCustomerPackage.oClientID = CustomerPackage.pCustomerPackage.addItem('oClientID', {"occurs":1});
CustomerPackage.pCustomerPackage.oTab_BLOC_CLIENT = CustomerPackage.pCustomerPackage.addItem('oTab_BLOC_CLIENT');


var TerminalInfos = ctx.addApplication('TerminalInfos', {"nature":"WEB3","path":"file://C:\\Users\\weaver7\\Desktop\\20190904_06 Hands-on Application\\Terminals\\Terminal.htm"});

TerminalInfos.pTerminalInfos = TerminalInfos.addPage('pTerminalInfos', {"comment":"file://C:\\Users\\weaver7\\Desktop\\20190904_06 Hands-on Application\\Terminals\\Terminal.htm","path":"file://C:\\Users\\weaver7\\Desktop\\20190904_06 Hands-on Application\\Terminals\\Terminal.htm"});
TerminalInfos.pTerminalInfos.oContract_id = TerminalInfos.pTerminalInfos.addItem('oContract_id');
TerminalInfos.pTerminalInfos.oSerial_number = TerminalInfos.pTerminalInfos.addItem('oSerial_number');
TerminalInfos.pTerminalInfos.oEquipment_type = TerminalInfos.pTerminalInfos.addItem('oEquipment_type');
TerminalInfos.pTerminalInfos.oOffer_type = TerminalInfos.pTerminalInfos.addItem('oOffer_type');
TerminalInfos.pTerminalInfos.oEligibility = TerminalInfos.pTerminalInfos.addItem('oEligibility');
TerminalInfos.pTerminalInfos.btSearch = TerminalInfos.pTerminalInfos.addItem('btSearch');
TerminalInfos.pTerminalInfos.btClear = TerminalInfos.pTerminalInfos.addItem('btClear');
TerminalInfos.pTerminalInfos.btDetails = TerminalInfos.pTerminalInfos.addItem('btDetails');

TerminalInfos.pTerminalDetails = TerminalInfos.addPage('pTerminalDetails', {"comment":"file://C:\\Users\\weaver7\\Desktop\\20190904_06 Hands-on Application\\Terminals\\resources\\Details1.htm","path":"file://C:\\Users\\weaver7\\Desktop\\20190904_06 Hands-on Application\\Terminals\\resources\\Details1.htm"});
TerminalInfos.pTerminalDetails.oDescription = TerminalInfos.pTerminalDetails.addItem('oDescription');
TerminalInfos.pTerminalDetails.oTms = TerminalInfos.pTerminalDetails.addItem('oTms');
TerminalInfos.pTerminalDetails.oTban = TerminalInfos.pTerminalDetails.addItem('oTban');
TerminalInfos.pTerminalDetails.oChargedate = TerminalInfos.pTerminalDetails.addItem('oChargedate');
TerminalInfos.pTerminalDetails.oContractname = TerminalInfos.pTerminalDetails.addItem('oContractname');
TerminalInfos.pTerminalDetails.oSoft = TerminalInfos.pTerminalDetails.addItem('oSoft');
TerminalInfos.pTerminalDetails.oTeleload = TerminalInfos.pTerminalDetails.addItem('oTeleload');
TerminalInfos.pTerminalDetails.oStatus = TerminalInfos.pTerminalDetails.addItem('oStatus');


var Partner = ctx.addApplication('Partner', {"nature":"WEB3","path":"file://C:\\Users\\weaver7\\Desktop\\20190904_06 Hands-on Application\\Partners\\outsourcer.htm"});

Partner.pPartner = Partner.addPage('pPartner', {"comment":"file://C:\\Users\\weaver7\\Desktop\\20190904_06 Hands-on Application\\Partners\\outsourcer.htm","path":"file://C:\\Users\\weaver7\\Desktop\\20190904_06 Hands-on Application\\Partners\\outsourcer.htm"});
Partner.pPartner.oContract_id = Partner.pPartner.addItem('oContract_id');
Partner.pPartner.oSerial_number = Partner.pPartner.addItem('oSerial_number');
Partner.pPartner.oRequest = Partner.pPartner.addItem('oRequest');
Partner.pPartner.btSend = Partner.pPartner.addItem('btSend');
Partner.pPartner.btClear = Partner.pPartner.addItem('btClear');
